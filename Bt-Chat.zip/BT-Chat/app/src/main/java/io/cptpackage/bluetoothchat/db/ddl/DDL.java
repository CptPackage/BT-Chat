package io.cptpackage.bluetoothchat.db.ddl;

public interface DDL {
    public String getTableCreationSchema();
}
